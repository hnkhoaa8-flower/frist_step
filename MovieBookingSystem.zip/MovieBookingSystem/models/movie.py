# models/movie.py

class Movie:
    def __init__(self, movie_id, title, genre, duration, ticket_price):
        self.movie_id = movie_id
        self.title = title
        self.genre = genre
        self.duration = int(duration)
        self.ticket_price = float(ticket_price)

    def __str__(self):
        # Format hiển thị đẹp: ID | Tên | Thể loại | Thời lượng | Giá
        return f"{self.movie_id} | {self.title} | {self.genre} | {self.duration} mins | ${self.ticket_price}"