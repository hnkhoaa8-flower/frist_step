# utils/file_helper.py
import os

def read_file(filename):
    """Đọc file và trả về danh sách các dòng, bỏ qua dòng trống"""
    data = []
    if not os.path.exists(filename):
        # Nếu file chưa có thì tạo file rỗng
        try:
            with open(filename, 'w', encoding='utf-8') as f: pass
        except Exception:
            pass
        return data

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    data.append(line.strip())
    except Exception as e:
        print(f"Error reading file {filename}: {e}")
    return data

def write_file(filename, data_list):
    """Ghi danh sách dữ liệu vào file"""
    try:
        # Đảm bảo thư mục data tồn tại
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        
        with open(filename, 'w', encoding='utf-8') as f:
            for item in data_list:
                f.write(str(item) + "\n")
    except Exception as e:
        print(f"Error writing file {filename}: {e}")