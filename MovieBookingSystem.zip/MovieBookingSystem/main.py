# main.py
# Import class quản lý từ thư mục services
from services.movie_manager import MovieManager
import sys

def main():
    print("Đang khởi động hệ thống...")
    try:
        manager = MovieManager()
    except Exception as e:
        print(f"Lỗi khởi tạo: {e}")
        return

    while True:
        print("\n=== HỆ THỐNG ĐẶT VÉ XEM PHIM (DEMO) ===")
        print("1. Xem danh sách phim")
        print("2. Thêm phim mới")
        print("0. Thoát")
        
        choice = input("Mời bạn chọn chức năng (0-2): ")

        if choice == '1':
            manager.display_movies()
        elif choice == '2':
            manager.add_movie()
        elif choice == '0':
            print("Cảm ơn đã sử dụng hệ thống!")
            break
        else:
            print("Lựa chọn không hợp lệ, vui lòng thử lại.")

if __name__ == "__main__":
    main()