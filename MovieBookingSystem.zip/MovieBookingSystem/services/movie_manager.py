# services/movie_manager.py
from models.movie import Movie
from utils.file_helper import read_file, write_file

# Đường dẫn file dữ liệu
MOVIE_FILE = 'data/movies.txt'

class MovieManager:
    def __init__(self):
        self.movies = []
        self.load_data()

    def load_data(self):
        self.movies.clear()
        lines = read_file(MOVIE_FILE)
        for line in lines:
            try:
                # Tách chuỗi bằng dấu gạch đứng |
                parts = line.split('|')
                # Cần làm sạch khoảng trắng thừa bằng .strip()
                if len(parts) >= 5:
                    m_id = parts[0].strip()
                    title = parts[1].strip()
                    genre = parts[2].strip()
                    # Xử lý chuỗi "120 mins" để lấy số 120
                    duration = parts[3].strip().replace(' mins', '')
                    # Xử lý chuỗi "$10.0" để lấy số 10.0
                    price = parts[4].strip().replace('$', '')
                    
                    new_movie = Movie(m_id, title, genre, duration, price)
                    self.movies.append(new_movie)
            except Exception as e:
                print(f"Error parsing line '{line}': {e}")

    def add_movie(self):
        print("\n--- NHẬP THÔNG TIN PHIM MỚI ---")
        m_id = input("Nhập ID Phim (VD: M01): ")
        title = input("Nhập Tên Phim: ")
        genre = input("Nhập Thể Loại: ")
        
        while True:
            try:
                duration = int(input("Nhập Thời Lượng (phút): "))
                break
            except ValueError:
                print("Lỗi: Vui lòng nhập số nguyên cho thời lượng.")

        while True:
            try:
                price = float(input("Nhập Giá Vé: "))
                break
            except ValueError:
                print("Lỗi: Vui lòng nhập số cho giá vé.")
        
        new_movie = Movie(m_id, title, genre, duration, price)
        self.movies.append(new_movie)
        self.save_data()
        print("=> Thêm phim thành công!")

    def display_movies(self):
        print("\n" + "="*60)
        print(f"{'ID':<8} | {'TÊN PHIM':<20} | {'THỂ LOẠI':<10} | {'THỜI GIAN':<10}")
        print("-" * 60)
        if not self.movies:
            print("(Danh sách trống)")
        else:
            for m in self.movies:
                print(f"{m.movie_id:<8} | {m.title:<20} | {m.genre:<10} | {m.duration} mins")
        print("="*60 + "\n")

    def save_data(self):
        # Chuyển đổi list object thành list string để ghi file
        # Format phải khớp với logic đọc file ở trên
        data_to_save = []
        for m in self.movies:
            # Lưu dạng gốc để dễ đọc lại: M01|Mai|Romance|120|10.0
            line = f"{m.movie_id}|{m.title}|{m.genre}|{m.duration}|{m.ticket_price}"
            data_to_save.append(line)
        
        write_file(MOVIE_FILE, data_to_save)